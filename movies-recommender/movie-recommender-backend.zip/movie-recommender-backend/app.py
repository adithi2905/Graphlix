from flask import Flask, jsonify, request
from flask_cors import CORS
import pandas as pd
import torch
import pickle
from model import EnhancedNGCF

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

# Load movies
def load_movies(filepath):
    movies = pd.read_csv(filepath, sep='::', engine='python', names=['movie_id', 'title', 'genres'], encoding='ISO-8859-1')
    movie_list = movies['title'].tolist()
    title_to_id = {row['title']: row['movie_id'] for _, row in movies.iterrows()}
    return movie_list, title_to_id

MOVIES, MOVIE_IDS = load_movies('movies.dat')

# Load graph structure
with open('graph_data.pkl', 'rb') as f:
    graph_data = pickle.load(f)

edge_index = graph_data['edge_index']
edge_attr = graph_data['edge_attr']

# Infer number of users and items
num_total_nodes = edge_index.max().item() + 1
user_nodes = edge_index[0].unique()
num_users = user_nodes.max().item() + 1
num_items = num_total_nodes - num_users
item_nodes = edge_index[1]

print(f"Loaded Graph: {num_users} users, {num_items} items")

# Load model
model = EnhancedNGCF(
    num_nodes=num_total_nodes,
    embedding_dim=128,
    hidden_dim=256,
    num_layers=3,
    dropout=0.2
)
model.load_state_dict(torch.load('enhanced_ngcf_model.pth', map_location=torch.device('cpu')))
model.eval()

# Corrected find user from movie id
def find_userid_from_movieid(movie_id):
    movie_embedding_index = num_users + (movie_id - 1)

    user_indices = edge_index[0]
    item_indices = edge_index[1]

    connected_users = user_indices[item_indices == movie_embedding_index]

    if len(connected_users) > 0:
        selected_user = connected_users[0].item()
    else:
        selected_user = None
    return selected_user

@app.route('/movies', methods=['GET'])
def get_movies():
    return jsonify({"movies": MOVIES})

@app.route('/recommend_by_movie', methods=['GET'])
def recommend_by_movie():
    movie_title = request.args.get('movie_title')

    if not movie_title:
        return jsonify({"error": "Missing movie title"}), 400

    print(f"Received movie title: {movie_title}")  # 🛠 Debug print

    movie_id = None
    for title, mid in MOVIE_IDS.items():
        if title.strip().lower() == movie_title.strip().lower():
            movie_id = mid
            break

    if movie_id is None:
        return jsonify({"error": f"Movie '{movie_title}' not found"}), 404

    user_id = find_userid_from_movieid(movie_id)
    if user_id is None:
        return jsonify({"error": "No user found for this movie"}), 404

    with torch.no_grad():
        embeddings = model(edge_index, edge_attr)
        user_emb = embeddings[:num_users]
        item_emb = embeddings[num_users:]

        user_vector = user_emb[user_id]
        scores = torch.matmul(user_vector, item_emb.T)

        topk_indices = torch.topk(scores, k=10).indices.tolist()

        recommended_movies = [MOVIES[idx] for idx in topk_indices]

    return jsonify({"recommendations": recommended_movies})

if __name__ == "__main__":
    app.run(debug=True)
