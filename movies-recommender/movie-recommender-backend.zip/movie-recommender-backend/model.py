import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data
import math

class EnhancedNGCF(nn.Module):
    """Enhanced Neural Graph Collaborative Filtering"""
    def __init__(self, num_nodes, embedding_dim=128, hidden_dim=256, num_layers=3, dropout=0.2, l2_reg=1e-4):
        super(EnhancedNGCF, self).__init__()
        self.embedding = nn.Embedding(num_nodes, embedding_dim)
        self.num_layers = num_layers
        self.dropout = dropout
        self.l2_reg = l2_reg

        torch.nn.init.xavier_uniform_(self.embedding.weight)

        self.W1 = nn.ModuleList([nn.Linear(embedding_dim, hidden_dim) for _ in range(num_layers)])
        self.W2 = nn.ModuleList([nn.Linear(embedding_dim, hidden_dim) for _ in range(num_layers)])
        self.W3 = nn.ModuleList([nn.Linear(hidden_dim, embedding_dim) for _ in range(num_layers)])

        self.batch_norms = nn.ModuleList([nn.BatchNorm1d(embedding_dim) for _ in range(num_layers)])

        self.attention = nn.ModuleList([
            nn.Sequential(
                nn.Linear(embedding_dim * 2, 64),
                nn.LeakyReLU(),
                nn.Linear(64, 1)
            ) for _ in range(num_layers)
        ])

    def forward(self, edge_index, edge_attr=None):
        x = self.embedding.weight
        all_embeddings = [x]

        for layer in range(self.num_layers):
            x = self.propagate(edge_index, x, layer, edge_attr)
            all_embeddings.append(x)

        stacked_embeddings = torch.stack(all_embeddings, dim=0)

        final_emb = torch.mean(stacked_embeddings, dim=0) + 0.1 * all_embeddings[0]

        return final_emb

    def propagate(self, edge_index, x, layer, edge_attr=None):
        row, col = edge_index

        if edge_attr is not None:
            edge_weight = edge_attr.squeeze()
        else:
            deg = torch.bincount(row, minlength=x.size(0)).float().pow(-0.5)
            deg[deg == float('inf')] = 0
            edge_weight = deg[row] * deg[col]

        element_product = x[row] * x[col]

        concat_features = torch.cat([x[row], x[col]], dim=1)
        attention_score = torch.sigmoid(self.attention[layer](concat_features))

        weighted_message = element_product * attention_score * edge_weight.unsqueeze(1)

        neighbor_info = torch.zeros_like(x).index_add_(0, row, weighted_message)

        transformed = self.W1[layer](neighbor_info) + self.W2[layer](x)
        transformed = F.leaky_relu(transformed)
        out = self.W3[layer](transformed)

        out = self.batch_norms[layer](out)

        out = out + x

        out = F.dropout(out, p=self.dropout, training=self.training)

        return out

    def l2_regularization_loss(self):
        l2_loss = 0.0
        for param in self.parameters():
            l2_loss += torch.norm(param, 2)
        return self.l2_reg * l2_loss
